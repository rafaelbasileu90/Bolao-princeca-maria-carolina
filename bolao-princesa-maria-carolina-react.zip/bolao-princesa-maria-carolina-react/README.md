
Bolão da Princesa Maria Carolina
================================

Projeto React (Vite) gerado automaticamente para publicação.

Como usar:
1. Instalar dependências:
   npm install

2. Rodar em desenvolvimento:
   npm run dev

3. Fazer build para produção:
   npm run build

Nota:
- Substitua os links em App.jsx (variáveis de wise) pelos teus links reais da Wise.
- Este pacote está pronto para upload direto ao Vercel (drop) ou Netlify.
