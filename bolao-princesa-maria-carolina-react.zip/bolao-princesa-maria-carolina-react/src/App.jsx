
import React, { useState } from 'react'
import { Heart, Flower2, Strawberry } from 'lucide-react'

const styles = {
  page: { minHeight: '100vh', background: '#F8F6F2', display:'flex', alignItems:'flex-start', justifyContent:'center', padding:'24px' },
  card: { maxWidth: '720px', width:'100%', background:'#fff', boxShadow:'0 10px 30px rgba(0,0,0,0.06)', borderRadius: '18px', padding:'24px', border: '1px solid #EADBCF' },
  title: { color: '#B43A3A', fontSize:'28px', margin:0, fontFamily: 'Georgia, "Times New Roman", serif' },
  subtitle: { color: '#9BB68C', marginTop:'8px' },
  currencyBtn: (active, color) => ({ padding:'8px 14px', borderRadius:999, border:'1px solid '+color, background: active ? color : '#fff', color: active ? '#fff' : color, cursor:'pointer' }),
  input: { width:'100%', padding:'10px', borderRadius:'8px', border:'1px solid #e6e6e6' },
  btnPrimary: { background:'#B43A3A', color:'#fff', padding:'12px 20px', borderRadius:999, border:'none', cursor:'pointer' },
  btnSecondary: { background:'#AFCFE4', color:'#fff', padding:'12px 20px', borderRadius:999, border:'none', cursor:'pointer' },
  footerIcons: { display:'flex', justifyContent:'center', gap:'10px', marginTop:'14px' },
  small: { fontSize:'14px', color:'#666' }
}

export default function App(){
  const [currency, setCurrency] = useState('EUR')
  const [amount, setAmount] = useState('')
  const [name, setName] = useState('')
  const [date, setDate] = useState('')
  const [time, setTime] = useState('')

  const today = new Date().toISOString().split('T')[0]
  const max = new Date(Date.now() + 30*24*60*60*1000).toISOString().split('T')[0]

  const handleSubmit = (e) => {
    e.preventDefault()
    if(!name || !date || !time){
      alert('Por favor preenche nome, data e hora.')
      return
    }
    alert(`Palpite registado!\nNome: ${name}\nData: ${date}\nHora: ${time}\nValor: ${amount || '0'} ${currency}`)
  }

  const buildWiseLink = () => {
    const base = currency === 'EUR' ? 'https://wise.com/pay/SEU_LINK_EURO?amount=' : 'https://wise.com/pay/SEU_LINK_REAL?amount='
    return base + (amount || '0')
  }

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={{textAlign:'center', marginBottom:18}}>
          <h1 style={styles.title}>👑 Bolão da Princesa Maria Carolina</h1>
          <p style={styles.subtitle}>Adivinha a data e hora do nascimento — participa com o valor que quiseres!</p>
        </div>

        <div style={{display:'flex', justifyContent:'center', gap:12, marginBottom:16}}>
          <button onClick={()=>setCurrency('EUR')} style={styles.currencyBtn(currency==='EUR','#AFCFE4')}>€ Euro</button>
          <button onClick={()=>setCurrency('BRL')} style={styles.currencyBtn(currency==='BRL','#B43A3A')}>R$ Real</button>
        </div>

        <form onSubmit={handleSubmit} style={{display:'grid', gap:12}}>
          <div>
            <label className="label">Nome</label>
            <input style={styles.input} value={name} onChange={(e)=>setName(e.target.value)} placeholder="Teu nome" required />
          </div>

          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
            <div>
              <label className="label">Data</label>
              <input type="date" style={styles.input} value={date} onChange={(e)=>setDate(e.target.value)} min={today} max={max} required />
            </div>
            <div>
              <label className="label">Hora</label>
              <input type="time" style={styles.input} value={time} onChange={(e)=>setTime(e.target.value)} required />
            </div>
          </div>

          <div>
            <label className="label">Valor ({currency})</label>
            <input type="number" min="0" step="0.01" style={styles.input} value={amount} onChange={(e)=>setAmount(e.target.value)} placeholder="Ex: 0, 5 ou 10" />
            <div style={{marginTop:8}} className="small">Exemplos: 0, 5, 10</div>
          </div>

          <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:10, marginTop:8}}>
            <a href={buildWiseLink()} target="_blank" rel="noreferrer" style={styles.btnPrimary}>💸 Enviar aposta via Wise</a>
            <button type="submit" style={styles.btnSecondary}>Registrar Palpite</button>
          </div>
        </form>

        <div style={{marginTop:20, textAlign:'center', color:'#9BB68C', fontSize:14}}>
          <div style={styles.footerIcons}>
            <Heart color="#B43A3A" size={18} />
            <Strawberry color="#B43A3A" size={18} />
            <Flower2 color="#9BB68C" size={18} />
          </div>
          <p style={{marginTop:8}}>Feito com amor por familiares e amigos — boa sorte e muita ternura à Princesa Maria Carolina 💕</p>
        </div>
      </div>
    </div>
  )
}
